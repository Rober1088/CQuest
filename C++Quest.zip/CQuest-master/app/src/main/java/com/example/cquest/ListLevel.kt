package com.example.cquest

data class Level(val Nivel: String, val Tema: String)


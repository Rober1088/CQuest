package com.example.cquest

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Activity_Menu : AppCompatActivity() {

    private lateinit var closeButton: ImageButton
    private lateinit var jugarNivelesButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)


        closeButton = findViewById(R.id.close_button)
        jugarNivelesButton = findViewById(R.id.JugarNiveles)


        if (::closeButton.isInitialized) {
            Log.d("Activity_Menu", "closeButton inicializado correctamente")
        } else {
            Log.e("Activity_Menu", "closeButton no se pudo inicializar")
        }


        closeButton.setOnClickListener {
            Log.d("Activity_Menu", "closeButton presionado")
            val intent = Intent(this, SignInActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        jugarNivelesButton.setOnClickListener {
            Log.d("Activity_Menu", "Jugar Niveles presionado")
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}

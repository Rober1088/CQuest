package com.example.cquest

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class PasswordActivity : AppCompatActivity() {

    private lateinit var passwordInput: EditText
    private lateinit var continueButton3: Button
    private lateinit var databaseHelper: DatabaseHelper

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_password)

        passwordInput = findViewById(R.id.password_input)
        continueButton3 = findViewById(R.id.continue_button4)

        databaseHelper = DatabaseHelper(this)

        continueButton3.setOnClickListener {
            savePassword()
        }

        findViewById<ImageButton>(R.id.close_button).setOnClickListener {
            finish()
        }
    }

    private fun savePassword() {
        val password = passwordInput.text.toString().trim()
        if (password.isEmpty()) {
            Toast.makeText(this, "Please enter your password", Toast.LENGTH_SHORT).show()
            return
        }

        val id = databaseHelper.getLastInsertedId()
        if (id != -1L) {

            val updateSuccess = databaseHelper.updatePassword(id, password)
            if (updateSuccess) {
                Toast.makeText(this, "Password saved successfully", Toast.LENGTH_SHORT).show()

                val userName = databaseHelper.getUserNameById(id)


                val intent = Intent(this, BienvenidaActivity::class.java)
                intent.putExtra("user_name", userName)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Failed to save password", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Failed to get last inserted ID", Toast.LENGTH_SHORT).show()
        }
    }
}
